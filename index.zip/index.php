<?php 
    echo "from index"
?>