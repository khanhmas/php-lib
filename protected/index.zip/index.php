<?php
//    if (($_SERVER['PHP_AUTH_USER'] != 'alexlu') || ($_SERVER['PHP_AUTH_PW'] != '1234')) {
//       header('WWW-Authenticate: Basic Realm="Secret Stash"');
//       header('HTTP/1.0 401 Unauthorized');
//       print('You must provide the proper credentials!');
//       exit;
//    } else {
//        echo 'from protected';
//    }
    echo 'from protected';
